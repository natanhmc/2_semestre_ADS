<div class="container-fluid">
    <div class="row">

        <h3>Bem vindo ao site </h3>
        <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias quisquam corporis quo quasi ullam adipisci quia mollitia 
            nisi, voluptas earum ducimus ea nostrum fugiat, voluptatem animi aliquid debitis enim inventore. Ex dolorem in nisi laudantiu
            m eveniet aspernatur sunt tenetur accusamus, odio dignissimos culpa. Voluptatum, facilis maiores. Aliquid earum illum tempora
             laudantium necessitatibus sunt id neque eum officia accusantium? Voluptas dolor accusantium vero suscipit magnam est numquam
              perferendis nostrum. Nam, illo. Nulla, voluptatibus magnam minima tempora voluptate corrupti fugit iste accusamus qui, elig
              endi magni, quidem a. Eos ad et amet quidem in fugit magni temporibus ipsa iure ea libero, quaerat eveniet. Quae aut praese
              ntium adipisci consectetur saepe quas hic est fuga deserunt maxime, pariatur voluptas labore dolorem libero, eligendi error
             .</h5>

    </div>

</div>