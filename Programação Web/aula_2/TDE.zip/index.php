
<?php
    include_once('templates/header.php');
    include_once('templates/footer.php');
?>
