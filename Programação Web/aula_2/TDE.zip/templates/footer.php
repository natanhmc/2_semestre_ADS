<footer class="bg-dark p-5 text-white text-center" >
    <h3>RÓDAPÉ</h3>
</footer>