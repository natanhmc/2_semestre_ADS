<html>
<head>
	<title>Lista de Arquivos</title>
</head>
<body>
<form method="POST" action="gravar_arquivos.php" enctype="multipart/form-data">
    Arquivo:
    <input type="file" name="foto"><br>
    <input type="submit" name="submit" value=" OK ">
</form>
</body>
</html>

