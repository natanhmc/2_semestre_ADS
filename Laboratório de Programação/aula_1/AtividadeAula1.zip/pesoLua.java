public class pesoLua {
    public static void main(String[] args){
        System.out.println(79*0.17);
    }
}
