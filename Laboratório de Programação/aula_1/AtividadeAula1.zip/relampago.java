public class relampago {
    public static void main(String[] args){
        System.out.println(1100*7.2);
    }

}
