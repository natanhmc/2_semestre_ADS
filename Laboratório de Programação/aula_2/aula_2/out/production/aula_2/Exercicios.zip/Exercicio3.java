public class Exercicio3 {
    public static void main(String[] args) {
        int F = 0;
        int ant = 0;
        int n=0;

        for (int i = 0; i <= 15; i++) {

            if (i == 1) {
                F = 1;
                ant = 0;
            } else {
                F += ant;
                ant = F - ant;
            }
            System.out.println("numero "+i+" Fibonacci: "+F);

        }

    }
    }
