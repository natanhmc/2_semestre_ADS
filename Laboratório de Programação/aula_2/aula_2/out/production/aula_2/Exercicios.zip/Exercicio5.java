import java.util.Scanner;
public class Exercicio5 {
    public static void main(String[] args) {
        float gas;
        float dist;
        float medio;
        Scanner scan = new Scanner(System.in);
        System.out.println("Informe a distancia percorrida:");
        dist = scan.nextFloat();
        System.out.println("Informe a quantidade de gasolina gassta:");
        gas = scan.nextFloat();
        scan.close();
        medio=gas/dist;
        System.out.println("o consumo medio foi de :"+medio);



    }
}
