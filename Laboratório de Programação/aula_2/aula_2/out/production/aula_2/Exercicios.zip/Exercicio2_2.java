public class Exercicio2_2 {
    public static void main(String[] args) {
        int i=1;
        int soma=0;
        do {
            soma=soma+i;
            i+=2;
            System.out.println("a soma e "+soma);
        }while (i<101);
    }
}
