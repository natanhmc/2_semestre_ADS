public class Exercicio2_3 {
    public static void main(String[] args) {
        int i=0;
        int soma=0;
        while (soma<100){
            System.out.println("numero: "+i+".Soma: "+soma);
            soma=soma+i;
            i++;
        }
    }
}
