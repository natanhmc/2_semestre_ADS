public class Exercicio1 {
    public static void main(String[] args){
        float nota1=8.5f;
        float nota2=7.5f;
        float nota3=6.0f;
        float media=(nota1+nota2+nota3)/10;
        System.out.println("a media e "+media);


    }
}
